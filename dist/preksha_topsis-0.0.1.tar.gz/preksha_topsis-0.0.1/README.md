# Preksha Topsis
It takes input of few items and calculates the topsis score among them and also gives the best alternative.

## Installation
'''pip install preksha_topsis'''

## How to use it?
Open terminal and type topsis and then input the values

## License

©️ 2024 Preksha Dadoo

This repository is licensed under the MIT license.
See LICENSE for details.